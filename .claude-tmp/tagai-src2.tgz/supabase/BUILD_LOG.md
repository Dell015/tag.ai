# Database build log

Built 2026-10-22 by Claude through the Supabase connector, in project **tag.ai** (ref `mqdwmrokvtvtexaecqdv`). The earlier project (acoiufjazugecoikegmy) is not used.

## What was applied (in order)
| Migration | File | Content |
|---|---|---|
| 002a_core_tables | `migrations/002_stage_b_core.sql` (part 1) | tables, triggers, weekly view, shop tables |
| 002b_functions | same file (part 2) | spend_coins, refund_coins, buy_shop_item, equip_item, complete_profile, confirm_adult, approve_suggestion, reject_suggestion, retire_cards |
| 002c_rls_and_grants | same file (part 3) | RLS on every table, column grants, function privileges |
| 002d_indexes_and_shop_policy | `migrations/003_indexes_and_shop_policy.sql` | FK indexes, shop policy without is_admin for signed-out users |
| 004_card_decks | `migrations/004_card_decks.sql` | `card_decks` link table (a card can be in several decks), filled with the app's deck rules (664 links), `approve_suggestion` adds the new card to its deck |

Data (run through the SQL tool from `seed/002_stage_b_seed.sql`, plus a starter `blocked_words` list of 17 words): 10 decks, 353 cards (143 adult, 1 retired), 109 topics, 21 shop items. Counts checked after loading.

## Fixes made to Kiro's draft before applying
Username check letters, numbers, underscore only; `public_profiles` and the private helper only for signed-in users; wider phone number rule; suggestion kinds limited to truth and dare; profiles update only the `settings` column; new tables, sequences and functions closed by default; added `complete_profile` and `confirm_adult`.

## Checks (tests/spec_checks.sql, run 2026-10-22): 13 of 13 pass
Welcome gift, coins not writable, ledger not writable, settings writable, pending suggestions private, no self approval, adult cards hidden until confirmed, overspend fails and changes nothing, refund cap, shop buy once, suggestion rules, 5 a day limit, no self like. Concurrency check 6 (two connections at once) is not run yet.

## Advisors
Security: no errors. Warnings are the app functions that signed-in users are meant to call, and leaked password protection (not relevant while sign in is a one-time email code; turn it on if passwords are ever added). Performance: FK indexes added; unused index notices are normal on an empty database.

## Open
- Two fake test users (`check-a@example.test`, `check-b@example.test`) remain until `manual/delete_test_users.sql` is run.
- Admin row: done for randelserafica1505@gmail.com (2026-10-22).
- Auth settings in the dashboard (email provider, redirect URLs) are not set yet.
- The two real accounts that existed before got profiles and the 10 coin welcome row by hand.
- Payments are the last milestone (owner 2026-10-22).

## App connection
See CLAUDE.md D39 and `docs/AUTH_SETUP.md`. Dashboard email template and SMTP are still to do.

Cards and topics are read from the database after sign in (CLAUDE.md D40). Real email sign in works (Resend SMTP, code template).

005_stacks applied 2026-10-25: stacks and stack_cards with row-level security and limits. Checked with two users: own stacks only, other users cannot read or add, adult cards refused until 18+ is confirmed, blank names refused.

006_pack_cards applied 2026-10-25: cards.pack_id, 48 pack cards, cards_select shows pack cards only to owners and admins. Checked with two users: owner-less player sees 0 pack cards, admin sees 48.

007_welcome_30 applied 2026-10-25: welcome gift trigger now gives 30 coins.

008_admin_give_coins applied 2026-10-25: admin-only RPC that adds coins through the ledger. Checked: admin gives 25, zero/fraction/unknown username refused, non-admin refused.

- 009_admin_give_coins_email: admin_give_coins now takes target_email (looked up in auth.users). Applied and tested (admin ok, unknown email rejected).
- 010_profile_photos: public avatars bucket (JPEG, 200KB), own-folder insert/update/delete policies, profiles.avatar accepts photo paths, complete_profile updated. Applied.
- 012_inbox: messages table + admin_send_message, mark_messages_read, claim_message. Applied; tested send to all, claim once, second claim refused.
- 013_cards_feed: posts, post_cheers, post_reports with RPCs. Applied. Tested as one user: post, duplicate refused, short refused, self-cheer refused, feed/top, own report hides, non-admin refused, delete. Cheering as a second user not tested (only one profile existed).
