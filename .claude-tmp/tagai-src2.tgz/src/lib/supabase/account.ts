/**
 * Everything the app asks of the real database, in one place. All calls use the signed-in
 * player's session and the public key; row-level security and the RPC functions decide what is allowed.
 */
import { getBrowserClient } from '@/lib/supabase/browser';
import { rpcArgs, type AuditRow } from '@/lib/audit';
import { clearFailures, lockSeconds, recordFailure } from '@/lib/throttle';
import type { QueuedCard } from '@/lib/game/escalation-engine';
import type { TalkTopic } from '@/lib/data/talk-topics';
import type { Remote } from '@/lib/data/remote-content';

export interface Result<T = unknown> { ok: boolean; error?: string; data?: T }

interface ProfileRow { id: string; username: string | null; avatar: string; coins: number | string; is_adult_confirmed: boolean; created_at: string }
interface TxRow { id: string; kind: string; amount: number | string; note: string | null; created_at: string }
interface OwnedRow { item_id: string; equipped: boolean }
interface CardIdRow { card_id: string }

export interface AccountData {
  userId: string;
  email: string | null;
  profile: { username: string | null; avatar: string; coins: number; adultConfirmed: boolean; createdAt: number };
  transactions: { id: string; kind: string; amount: number; note: string; at: number }[];
  owned: string[];
  equippedIds: string[];
  saved: string[];
  trashed: string[];
  isAdmin: boolean;
}

const num = (v: number | string): number => (typeof v === 'number' ? v : parseFloat(v));
const msg = (e: { message?: string } | null | undefined): string => {
  const m = typeof e?.message === 'string' ? e.message.trim() : '';
  // An empty or JSON-ish body ("{}") is not a message a player can read.
  if (!m || /^[{[]/.test(m)) return 'Something went wrong. Try again.';
  return m;
};
/** Friendly text for the errors the database raises on purpose. */
export const friendly = (m: string): string => {
  if (/Not enough coins/i.test(m)) return 'Not enough coins.';
  if (/name is taken/i.test(m)) return 'That name is taken. Try another.';
  if (/Name must be/i.test(m)) return 'Use 2 to 16 letters, numbers or underscores.';
  if (/rate limit|too many/i.test(m)) return 'Too many tries. Wait a minute and try again.';
  return m;
};

const noClient = { ok: false, error: 'Not connected' } as const;

export async function sendEmailCode(email: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.auth.signInWithOtp({ email: email.trim(), options: { shouldCreateUser: true } });
  if (!error) return { ok: true };
  const status = (error as { status?: number }).status;
  if (/rate limit|too many/i.test(error.message ?? '') || status === 429) {
    return { ok: false, error: 'Too many tries. Wait a minute and try again.' };
  }
  if (!error.message || status === 500 || /^[{[]/.test(error.message.trim())) {
    return { ok: false, error: 'We could not send the code to that email right now. Try again in a minute.' };
  }
  return { ok: false, error: friendly(msg(error)) };
}

export async function verifyEmailCode(email: string, token: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.auth.verifyOtp({ email: email.trim(), token: token.trim(), type: 'email' });
  return error ? { ok: false, error: 'That code did not work. Check it or ask for a new one.' } : { ok: true };
}

const authText = (m: string | undefined, fallback: string): string => {
  const t = (m ?? '').trim();
  if (/invalid login credentials/i.test(t)) return 'Wrong email or password.';
  if (/already registered|already been registered/i.test(t)) return 'That email already has an account. Sign in instead.';
  if (/password should be|weak password|at least/i.test(t)) return 'Use a password with at least 8 characters.';
  if (/rate limit|too many/i.test(t)) return 'Too many tries. Wait a minute and try again.';
  if (/failed to fetch|network|load failed/i.test(t)) return 'No connection. Check your internet and try again.';
  if (/email not confirmed/i.test(t)) return 'This account is not confirmed yet. Ask for help at the table.';
  if (!t || /^[{[]/.test(t)) return fallback;
  return t;
};

/** Makes an account with an email and a password. Needs "Confirm email" switched off in Supabase, since no email is sent. */
export async function signUpWithPassword(email: string, password: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.auth.signUp({ email: email.trim(), password });
  if (error) return { ok: false, error: authText(error.message, 'Could not create the account. Try again.') };
  // With email confirmation on, no session comes back and a mail is needed, which this app cannot send yet.
  if (!data.session) return { ok: false, error: 'This email may already have an account. Try signing in.' };
  return { ok: true };
}

export async function signInWithPassword(email: string, password: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const wait = lockSeconds();
  if (wait > 0) return { ok: false, error: `Too many tries. Wait ${wait} seconds, then try again.` };
  const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password });
  if (error) { recordFailure(); return { ok: false, error: authText(error.message, 'Could not sign in. Try again.') }; }
  clearFailures();
  return { ok: true };
}

/** Whether the email code option is shown. Set NEXT_PUBLIC_CODE_SIGNIN=on once sign in emails can reach everyone (verified domain in Resend). */
export const codeLoginEnabled = process.env.NEXT_PUBLIC_CODE_SIGNIN === 'on';

/** Forces the Google button on (on) or off (off). Left unset, the app asks Supabase whether Google is switched on. */
const GOOGLE_FLAG = process.env.NEXT_PUBLIC_GOOGLE_SIGNIN;
export const googleEnabled = GOOGLE_FLAG === 'on';

let googleAsk: Promise<boolean> | undefined;
/** True when Google sign in is enabled for this project. Asks Supabase once, so the button shows up as soon as the provider is switched on. */
export function googleAvailable(): Promise<boolean> {
  if (GOOGLE_FLAG === 'on') return Promise.resolve(true);
  if (GOOGLE_FLAG === 'off') return Promise.resolve(false);
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return Promise.resolve(false);
  googleAsk ??= fetch(`${url}/auth/v1/settings`, { headers: { apikey: key } })
    .then((r) => (r.ok ? r.json() : null))
    .then((j: { external?: { google?: boolean } } | null) => !!j?.external?.google)
    .catch(() => false);
  return googleAsk;
}

/** Sends the player to Google; they come back to /welcome with a session. */
export async function signInWithGoogle(next?: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: `${window.location.origin}/welcome${next && next.startsWith('/') ? `?next=${encodeURIComponent(next)}` : ''}` } });
  return error ? { ok: false, error: 'Google sign in is not available right now.' } : { ok: true };
}

export async function signOutServer(): Promise<void> {
  await getBrowserClient()?.auth.signOut();
}

/** Loads the signed-in player's account, or null when there is no session. */
export async function loadAccount(): Promise<AccountData | null> {
  const sb = getBrowserClient();
  if (!sb) return null;
  const { data: sess } = await sb.auth.getSession();
  const user = sess.session?.user;
  if (!user) return null;

  const [p, t, o, s, tr, a] = await Promise.all([
    sb.from('profiles').select('id, username, avatar, coins, is_adult_confirmed, created_at').eq('id', user.id).maybeSingle(),
    sb.from('transactions').select('id, kind, amount, note, created_at').order('created_at', { ascending: false }).limit(200),
    sb.from('owned_items').select('item_id, equipped'),
    sb.from('saved_cards').select('card_id'),
    sb.from('trashed_cards').select('card_id'),
    sb.from('admins').select('user_id').eq('user_id', user.id).maybeSingle(),
  ]);
  const profile = p.data as ProfileRow | null;
  if (!profile) return null;
  const owned = (o.data ?? []) as OwnedRow[];
  return {
    userId: user.id,
    email: user.email ?? null,
    profile: {
      username: profile.username,
      avatar: profile.avatar,
      coins: Math.floor(num(profile.coins)),
      adultConfirmed: profile.is_adult_confirmed,
      createdAt: Date.parse(profile.created_at) || Date.now(),
    },
    transactions: ((t.data ?? []) as TxRow[]).map((r) => ({ id: r.id, kind: r.kind, amount: num(r.amount), note: r.note ?? '', at: Date.parse(r.created_at) || Date.now() })),
    owned: owned.map((r) => r.item_id),
    equippedIds: owned.filter((r) => r.equipped).map((r) => r.item_id),
    saved: ((s.data ?? []) as CardIdRow[]).map((r) => r.card_id),
    trashed: ((tr.data ?? []) as CardIdRow[]).map((r) => r.card_id),
    isAdmin: !!a.data,
  };
}

export async function completeProfile(username: string, avatar: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('complete_profile', { username, avatar });
  return error ? { ok: false, error: friendly(msg(error)) } : { ok: true };
}

export async function confirmAdult(): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('confirm_adult');
  return error ? { ok: false, error: friendly(msg(error)) } : { ok: true };
}

export async function rpcSpend(kind: 'pot' | 'shop' | 'purchase', amount: number, note: string): Promise<Result<number>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('spend_coins', { kind, amount, note });
  return error ? { ok: false, error: friendly(msg(error)) } : { ok: true, data: num(data as number | string) };
}

export async function rpcRefund(amount: number, note: string): Promise<Result<number>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('refund_coins', { amount, note });
  return error ? { ok: false, error: friendly(msg(error)) } : { ok: true, data: num(data as number | string) };
}

export async function rpcBuyItem(itemId: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('buy_shop_item', { item_id: itemId });
  return error ? { ok: false, error: friendly(msg(error)) } : { ok: true };
}

export async function rpcEquip(itemId: string, on: boolean): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('equip_item', { item_id: itemId, on_off: on });
  return error ? { ok: false, error: friendly(msg(error)) } : { ok: true };
}

/** Saved and trashed cards. Own rows only; the user id comes from the session by default. */
export async function setCardMark(table: 'saved_cards' | 'trashed_cards', cardId: string, on: boolean): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = on
    ? await sb.from(table).upsert({ card_id: cardId }, { onConflict: 'user_id,card_id', ignoreDuplicates: true })
    : await sb.from(table).delete().eq('card_id', cardId);
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export async function saveSettings(settings: Record<string, unknown>, userId: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.from('profiles').update({ settings }).eq('id', userId);
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

// ─── Cards and topics ────────────────────────────────────────────────────────

interface CardRow {
  id: string; text: string; kind: string; card_type: 'question' | 'action' | 'wild'; intensity: number; category: string;
  topics: string[] | null; adult: boolean; wild_type: string | null; extra: Record<string, unknown> | null; pack_id: string | null;
}
interface TopicRow { id: string; group: string; format: string | null; text: string; deeper: string | null; a: string | null; b: string | null; topics: string[] | null }

export type RemoteContent = Remote;

/** Cards and talk topics the database says are approved. Row-level security hides retired cards and, until 18+ is confirmed, adult ones. */
export async function loadContent(): Promise<Result<RemoteContent>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const [c, t] = await Promise.all([
    sb.from('cards').select('id,text,kind,card_type,intensity,category,topics,adult,wild_type,extra,pack_id').eq('status', 'approved').order('id').limit(2000),
    sb.from('talk_topics').select('id,group,format,text,deeper,a,b,topics').eq('status', 'approved').order('id').limit(2000),
  ]);
  if (c.error) return { ok: false, error: msg(c.error) };
  if (t.error) return { ok: false, error: msg(t.error) };
  const cards: QueuedCard[] = [];
  const packs: Record<string, QueuedCard[]> = {};
  for (const r of (c.data ?? []) as unknown as CardRow[]) {
    const card: QueuedCard = {
      ...(r.extra ?? {}),
      id: r.id, text: r.text, cardType: r.card_type, intensity: r.intensity, category: r.category as QueuedCard['category'],
      topics: r.topics ?? [], kind: r.kind as QueuedCard['kind'],
      ...(r.adult ? { adult: true } : {}),
      ...(r.wild_type ? { wildCardType: r.wild_type as QueuedCard['wildCardType'] } : {}),
    };
    if (r.pack_id) (packs[r.pack_id] ??= []).push(card);
    else cards.push(card);
  }
  const topics = ((t.data ?? []) as unknown as TopicRow[]).map((r): TalkTopic => ({
    id: r.id, group: r.group as TalkTopic['group'], text: r.text, topics: r.topics ?? [],
    ...(r.format ? { format: r.format as TalkTopic['format'] } : {}),
    ...(r.deeper ? { deeper: r.deeper } : {}),
    ...(r.a ? { a: r.a } : {}), ...(r.b ? { b: r.b } : {}),
  }));
  return { ok: true, data: { cards, topics, packs } };
}

// ─── Admin ───────────────────────────────────────────────────────────────────
// These only work for admins: row-level security and the RPC functions refuse everyone else.

export interface PendingSuggestion { id: string; text: string; kind: string; deckId: string; authorName: string; createdAt: number }
export interface AdminCard { id: string; text: string; kind: string; deckId: string | null; adult: boolean; status: string; source: string }

export async function adminPending(): Promise<Result<PendingSuggestion[]>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.from('suggestions').select('id,text,kind,deck_id,author_id,created_at').eq('status', 'pending').order('created_at').limit(100);
  if (error) return { ok: false, error: msg(error) };
  const rows = (data ?? []) as { id: string; text: string; kind: string; deck_id: string; author_id: string; created_at: string }[];
  const ids = Array.from(new Set(rows.map((r) => r.author_id)));
  const names = new Map<string, string>();
  if (ids.length) {
    const p = await sb.from('public_profiles').select('id,username').in('id', ids);
    for (const r of (p.data ?? []) as { id: string; username: string | null }[]) names.set(r.id, r.username ?? 'Someone');
  }
  return { ok: true, data: rows.map((r) => ({ id: r.id, text: r.text, kind: r.kind, deckId: r.deck_id, authorName: names.get(r.author_id) ?? 'Someone', createdAt: Date.parse(r.created_at) })) };
}

export async function adminApprove(id: string, intensity?: number, category?: string): Promise<Result<string>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('approve_suggestion', { id, intensity: intensity ?? null, category: category ?? null });
  return error ? { ok: false, error: msg(error) } : { ok: true, data: data as string };
}

export async function adminReject(id: string, reason: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('reject_suggestion', { id, reason: reason.trim() || null });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

/** Finds cards by words in their text (approved and retired), newest first. */
export async function adminSearchCards(query: string): Promise<Result<AdminCard[]>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const q = query.trim().replace(/[%_,()]/g, ' ').slice(0, 60);
  let req = sb.from('cards').select('id,text,kind,deck_id,adult,status,source').order('created_at', { ascending: false }).limit(30);
  if (q) req = req.ilike('text', `%${q}%`);
  const { data, error } = await req;
  if (error) return { ok: false, error: msg(error) };
  return { ok: true, data: ((data ?? []) as { id: string; text: string; kind: string; deck_id: string | null; adult: boolean; status: string; source: string }[]).map((r) => ({ id: r.id, text: r.text, kind: r.kind, deckId: r.deck_id, adult: r.adult, status: r.status, source: r.source })) };
}

export async function adminRetire(ids: string[]): Promise<Result<number>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('retire_cards', { card_ids: ids });
  return error ? { ok: false, error: msg(error) } : { ok: true, data: data as number };
}

/** Gives coins to a player by email (admins only; the database refuses anyone else). Returns their new balance. */
export async function adminGiveCoins(email: string, amount: number, note: string): Promise<Result<number>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('admin_give_coins', { target_email: email.trim(), amount, note: note || null });
  return error ? { ok: false, error: msg(error) } : { ok: true, data: Number(data) };
}

export async function adminWords(): Promise<Result<string[]>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.from('blocked_words').select('word').order('word');
  return error ? { ok: false, error: msg(error) } : { ok: true, data: ((data ?? []) as { word: string }[]).map((r) => r.word) };
}

export async function adminAddWord(word: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.from('blocked_words').upsert({ word: word.trim().toLowerCase() }, { onConflict: 'word' });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export async function adminRemoveWord(word: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.from('blocked_words').delete().eq('word', word);
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

// ─── Stacks ──────────────────────────────────────────────────────────────────

export interface StackData { id: string; name: string; cardIds: string[]; updatedAt: number }

export async function loadStacks(): Promise<Result<StackData[]>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const [s, c] = await Promise.all([
    sb.from('stacks').select('id,name,created_at').order('created_at', { ascending: false }).limit(50),
    sb.from('stack_cards').select('stack_id,card_id').order('added_at').limit(5000),
  ]);
  if (s.error) return { ok: false, error: msg(s.error) };
  if (c.error) return { ok: false, error: msg(c.error) };
  const byStack = new Map<string, string[]>();
  for (const r of (c.data ?? []) as { stack_id: string; card_id: string }[]) byStack.set(r.stack_id, [...(byStack.get(r.stack_id) ?? []), r.card_id]);
  return { ok: true, data: ((s.data ?? []) as { id: string; name: string; created_at: string }[]).map((r) => ({ id: r.id, name: r.name, cardIds: byStack.get(r.id) ?? [], updatedAt: Date.parse(r.created_at) })) };
}

export async function createStackRemote(name: string): Promise<Result<string>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.from('stacks').insert({ name }).select('id').single();
  return error || !data ? { ok: false, error: msg(error) } : { ok: true, data: (data as { id: string }).id };
}

export async function renameStackRemote(id: string, name: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.from('stacks').update({ name }).eq('id', id);
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export async function deleteStackRemote(id: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.from('stacks').delete().eq('id', id);
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export async function addStackCardsRemote(id: string, cardIds: string[]): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.from('stack_cards').upsert(cardIds.map((card_id) => ({ stack_id: id, card_id })), { onConflict: 'stack_id,card_id', ignoreDuplicates: true });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export async function removeStackCardRemote(id: string, cardId: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.from('stack_cards').delete().eq('stack_id', id).eq('card_id', cardId);
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export interface InboxMessage { id: string; title: string; body: string; coins: number; at: number; read: boolean; claimed: boolean; link?: string }
interface MessageRow { id: string; title: string; body: string; coins: number; created_at: string; read_at: string | null; claimed_at: string | null; link?: string | null }

/** The signed-in player's inbox, newest first. */
export async function fetchInbox(): Promise<Result<InboxMessage[]>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.from('messages').select('id,title,body,coins,created_at,read_at,claimed_at,link').order('created_at', { ascending: false }).limit(50);
  if (error) return { ok: false, error: msg(error) };
  return { ok: true, data: ((data ?? []) as MessageRow[]).map((m) => ({ id: m.id, title: m.title, body: m.body, coins: m.coins, at: Date.parse(m.created_at), read: !!m.read_at, claimed: !!m.claimed_at, link: m.link ?? undefined })) };
}

export async function markInboxRead(): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('mark_messages_read');
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

/** Claims the coin gift on a message, once. Returns the new balance. */
export async function claimMessage(id: string): Promise<Result<number>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('claim_message', { msg_id: id });
  return error ? { ok: false, error: msg(error) } : { ok: true, data: Number(data) };
}

/** Sends a message (admins only). Empty email means everyone. Returns how many players got it. */
export async function adminSendMessage(email: string, title: string, body: string, coins: number): Promise<Result<number>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('admin_send_message', { target_email: email.trim() || null, msg_title: title.trim(), msg_body: body.trim(), msg_coins: coins });
  return error ? { ok: false, error: msg(error) } : { ok: true, data: Number(data) };
}

export interface FeedPost { id: string; authorId: string; authorName: string; authorAvatar: string; kind: string; deckId: string; body: string; at: number; cheers: number; mine: boolean; cheered: boolean }
interface PostRow { id: string; author_id: string; author_name: string; author_avatar: string; kind: string; deck_id: string; body: string; created_at: string; cheers: number; mine: boolean; cheered: boolean }

export interface FeedQuery { sort: 'new' | 'top'; dir: 'desc' | 'asc'; period: 'day' | 'week' | 'month' | 'all'; kind: string | null; deck: string | null; adult: boolean }

/** The Cards feed. `new` orders by time, `top` by cheers that count; `dir` flips either one. */
export async function fetchFeed(q: FeedQuery): Promise<Result<FeedPost[]>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('list_posts', { p_sort: q.sort, p_dir: q.dir, p_period: q.period, p_kind: q.kind, p_deck: q.deck, p_adult: q.adult, p_limit: 40 });
  if (error) return { ok: false, error: msg(error) };
  return { ok: true, data: ((data ?? []) as PostRow[]).map((p) => ({ id: p.id, authorId: p.author_id, authorName: p.author_name, authorAvatar: p.author_avatar, kind: p.kind, deckId: p.deck_id, body: p.body, at: Date.parse(p.created_at), cheers: p.cheers, mine: p.mine, cheered: p.cheered })) };
}

export async function createPost(kind: string, deck: string, body: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('create_post', { p_kind: kind, p_deck: deck, p_body: body });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export async function cheerPost(id: string): Promise<Result<{ cheers: number; cheered: boolean }>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('cheer_post', { p_post: id });
  const row = (Array.isArray(data) ? data[0] : data) as { cheers: number; cheered: boolean } | undefined;
  return error || !row ? { ok: false, error: msg(error) } : { ok: true, data: row };
}

export async function reportPost(id: string, reason?: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('report_post', { p_post: id, p_reason: reason ?? null });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export async function deletePost(id: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('delete_post', { p_post: id });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export interface ReportedPost { id: string; authorName: string; kind: string; deckId: string; body: string; hidden: boolean; reports: number }
export async function adminReportedPosts(): Promise<Result<ReportedPost[]>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('admin_reported_posts');
  if (error) return { ok: false, error: msg(error) };
  return { ok: true, data: ((data ?? []) as { id: string; author_name: string; kind: string; deck_id: string; body: string; hidden: boolean; reports: number }[]).map((p) => ({ id: p.id, authorName: p.author_name, kind: p.kind, deckId: p.deck_id, body: p.body, hidden: p.hidden, reports: p.reports })) };
}

export async function adminRestorePost(id: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('admin_restore_post', { p_post: id });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export interface PaymentRequest { id: string; ref: string; price_php: number; coins: number; status: 'pending' | 'paid' | 'rejected' | 'cancelled'; created_at: string }
export interface AdminPaymentRequest extends PaymentRequest { email: string; username: string | null; receipt_path: string | null }

/** Asks for a coin package. The price and coins are decided by the database, not by this screen. */
export async function createPaymentRequest(packageId: string): Promise<Result<PaymentRequest>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('create_payment_request', { p_package: packageId });
  const row = (Array.isArray(data) ? data[0] : data) as PaymentRequest | undefined;
  return error || !row ? { ok: false, error: msg(error) || 'Could not start the payment.' } : { ok: true, data: { ...row, status: 'pending', created_at: new Date().toISOString() } };
}

export async function myPaymentRequests(): Promise<Result<PaymentRequest[]>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('my_payment_requests');
  return error ? { ok: false, error: msg(error) } : { ok: true, data: (data ?? []) as PaymentRequest[] };
}

export async function cancelPaymentRequest(id: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('cancel_payment_request', { p_id: id });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

export async function adminPaymentRequests(): Promise<Result<AdminPaymentRequest[]>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('admin_payment_requests');
  return error ? { ok: false, error: msg(error) } : { ok: true, data: (data ?? []) as AdminPaymentRequest[] };
}

/** The money arrived: credits the coins once. Returns the player's new balance. */
export async function adminCompletePayment(id: string): Promise<Result<number>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('admin_complete_payment', { p_id: id });
  return error ? { ok: false, error: msg(error) } : { ok: true, data: Number(data) };
}

export async function adminRejectPayment(id: string, reason: string): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { error } = await sb.rpc('admin_reject_payment', { p_id: id, p_reason: reason || null });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

/** Uploads a receipt screenshot (already a small JPEG) and attaches it to a waiting request. */
export async function uploadReceipt(requestId: string, userId: string, blob: Blob): Promise<Result> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const path = `${userId}/${requestId}-${Date.now()}.jpg`;
  const up = await sb.storage.from('receipts').upload(path, blob, { contentType: 'image/jpeg', upsert: false });
  if (up.error) return { ok: false, error: 'Could not upload the receipt. Try again, or type the code in your payment message.' };
  const { error } = await sb.rpc('attach_receipt', { p_id: requestId, p_path: path });
  return error ? { ok: false, error: msg(error) } : { ok: true };
}

/** A short lived link to a receipt, for admins. */
export async function receiptUrl(path: string): Promise<string | null> {
  const sb = getBrowserClient();
  if (!sb) return null;
  const { data } = await sb.storage.from('receipts').createSignedUrl(path, 120);
  return data?.signedUrl ?? null;
}

export interface AuditPage { rows: AuditRow[]; total: number }

/** One page of the audit log. Admins only; the database refuses anyone else. */
export async function adminAuditLog(args: ReturnType<typeof rpcArgs>): Promise<Result<AuditPage>> {
  const sb = getBrowserClient();
  if (!sb) return noClient;
  const { data, error } = await sb.rpc('admin_audit_log', args);
  if (error) return { ok: false, error: msg(error) };
  const rows = ((data ?? []) as (AuditRow & { total: number | string })[]);
  return { ok: true, data: { rows: rows.map((r) => { const { total, ...rest } = r; void total; return { ...rest, amount: rest.amount == null ? null : Number(rest.amount) }; }), total: rows.length ? Number(rows[0].total) : 0 } };
}
